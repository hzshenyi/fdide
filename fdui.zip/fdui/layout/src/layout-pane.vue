<template>
  <div class="fd-layout-pane">
      <slot></slot>
  </div>
</template>

<script>
export default {
    name:"fd-layout-pane"
}
</script>