<template>
   
</template>

<script>
import {ref,reactive,getCurrentInstance} from 'vue' 
export default {
    setup(){
        let ctx = getCurrentInstance().ctx;
       return {
           
        }
    }
}
</script>