<template>
<MainFrame></MainFrame>
</template>
<style>
</style>
<script>
import MainFrame from './webide/frame/main.vue'
export default {
  name: 'App',
  components: {
    MainFrame
  }
}
</script>
